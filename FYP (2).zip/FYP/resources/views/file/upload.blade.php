@extends(class.thisclass)
@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-6 col-md-offset-4">
            <div class="card">
                <div class="card-header">File Upload
                    <div class="card-body">
                        <form action="{{route('uploadfile')}}" method="post" enctype="multi-part/form-data">
                            @csrf
                            <div class="form-group">
                                <input type="file" name="file">
                            </div>
                            <button type="submit" class="btn btn-primary">Upload</button>
                            <a href="{{route('viewfile')}}" class="btn brn-success">Back</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
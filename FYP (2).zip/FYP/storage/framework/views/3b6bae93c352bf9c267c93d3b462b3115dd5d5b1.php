
<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <strong><?php echo e(session('success')); ?></strong>
            </div>
        <?php endif; ?>
        <p>
            <a href="<?php echo e(route('formfile')); ?>" class="btn btn-primary">Upload File</a>
        </p>
        <div class="row">
            <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <div class="card">
                    <img class="card-img-top" src="<?php echo e(Storage::url($file->path)); ?>" alt="">
                    <div class="card-body">
                        <strong class="card-title"><?php echo e($file->title); ?></strong>
                        <p class="card-text"><?php echo e($file->created_at->diffForHumans()); ?></p>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?><?php /**PATH C:\Users\shivaramshrestha\Desktop\FYP\FYP\resources\views/file/index.blade.php ENDPATH**/ ?>